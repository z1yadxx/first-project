// 1. Kan jibou l 3anasir mn l HTML
const formulaire = document.getElementById("formulaire");
const champ = document.getElementById("champ");
const liste = document.getElementById("liste");
const compteur = document.getElementById("compteur");

// 2. L tâches kaytkhzno f tableau, o kan7ffdouhom f navigateur (localStorage)
let taches = [];
try {
  taches = JSON.parse(localStorage.getItem("taches")) || [];
} catch (erreur) {
  taches = [];
}

function sauvegarder() {
  try {
    localStorage.setItem("taches", JSON.stringify(taches));
  } catch (erreur) {
    // ila localStorage ma khddamch, makaynch moshkil, ghir ma kayt7ffdouch
  }
}

// 3. Had la fonction kat3awd tr7sm l liste kamla
function afficher() {
  liste.innerHTML = "";

  if (taches.length === 0) {
    liste.innerHTML = '<li class="vide">Aucune tâche pour le moment. Ajoute la première !</li>';
  }

  taches.forEach(function (tache, index) {
    const li = document.createElement("li");
    if (tache.finie) li.classList.add("finie");

    // checkbox
    const case_ = document.createElement("input");
    case_.type = "checkbox";
    case_.checked = tache.finie;
    case_.addEventListener("change", function () {
      taches[index].finie = !taches[index].finie;
      mettreAJour();
    });

    // texte (textContent bach nt7mmou mn code mkhtari)
    const texte = document.createElement("span");
    texte.textContent = tache.texte;
    texte.addEventListener("click", function () {
      taches[index].finie = !taches[index].finie;
      mettreAJour();
    });

    // bouton supprimer
    const bouton = document.createElement("button");
    bouton.className = "supprimer";
    bouton.textContent = "×";
    bouton.setAttribute("aria-label", "Supprimer la tâche");
    bouton.addEventListener("click", function () {
      taches.splice(index, 1);
      mettreAJour();
    });

    li.append(case_, texte, bouton);
    liste.appendChild(li);
  });

  // compteur
  const restantes = taches.filter(function (t) { return !t.finie; }).length;
  compteur.textContent = restantes + " tâche(s) restante(s) sur " + taches.length;
}

function mettreAJour() {
  sauvegarder();
  afficher();
}

// 4. Mnin kankliki 3la "Ajouter"
formulaire.addEventListener("submit", function (evenement) {
  evenement.preventDefault(); // kayb9a l page ma kay3awdch t7mmel
  const texte = champ.value.trim();
  if (texte === "") return;

  taches.push({ texte: texte, finie: false });
  champ.value = "";
  mettreAJour();
});

// 5. Awwal mra kat7ll l page
afficher();
